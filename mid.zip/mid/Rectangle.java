public class Rectangle implements Shape{
    int height;
    int width;

    public Rectangle(int height, int width) {
        this.height = height;
        this.width = width;
    }

    @Override
    public double getArea() {
        return height*width*1.0;
    }

    @Override
    public double getPerimeter() {
        return 2*(height+width);
    }

    @Override
    public String toString() {
        return "Rectangle";
    }
}
