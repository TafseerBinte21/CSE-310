public class Square implements Shape {
    int length;

    public Square(int length) {
        this.length = length;
    }

    @Override
    public double getArea() {
        return length*length;
    }

    @Override
    public double getPerimeter() {
        return 4*length;
    }

    @Override
    public String toString() {
        return "Square";
    }
}
