public class ShapePrinter {
    public static void print(Shape shape) {
        System.out.println("Shape: " + shape);
        System.out.println("AREA: " + shape.getArea());
        System.out.println("PERIMETER: " + shape.getPerimeter());
        System.out.println();
    }
}