import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class task1 {

    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        String path = sc.nextLine();
        File file = new File(path);
        sc = new Scanner(file);
        String output = "";
        while (sc.hasNextLine()) {
            String l = sc.nextLine();
            char array[] = l.toCharArray();
            for (int i = 0; i <= array.length; i++) {
                int a = (int)array[i];
                if (a >= 48 & a <= 57) {
                    output += (char)a;
                } else if (a >= 65 & a <= 90) {
                    output += (char)a;
                } else if (a >= 97 & a <= 122) {
                    output += (char)a;
                }


            }

        }
        FileWriter out = new FileWriter("output.txt");
        out.write(output);
        out.close();

    }
}