class TestAbstractClassWithInterfaceImplementation{  
public static void main(String args[]){  
InterfaceA a=new InheritAbstractClassThatImplementsInterface();  
a.a();  
a.b();  
a.c();  
a.d();  
}} 