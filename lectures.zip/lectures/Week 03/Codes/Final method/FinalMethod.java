class FinalMethod
{
  final void method1()
  {
    System.out.println("I am method 1 of parent class");
  }
}