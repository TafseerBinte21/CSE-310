//This code will give an error becasue you cannot extend a final class
class InheritFinalClass extends FinalClass
{
  public static void main(String []args)
  {
    System.out.println("Hello");
  }
}