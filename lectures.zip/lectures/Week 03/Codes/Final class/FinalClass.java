final class FinalClass
{
  int a = 0;
  int b = 0;
}

