//Multiple inheritance using a class implementing multiple interface
interface Printable{  
void print();  
}  
interface Showable{  
void show();  
}  
