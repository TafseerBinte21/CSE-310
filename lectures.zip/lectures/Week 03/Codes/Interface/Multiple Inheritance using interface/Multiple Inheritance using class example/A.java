class A
{
  public void method1()
  {
    System.out.println("Hi , I am method1 is class A");
  }
}

class B
{
  public void method1()
  {
    System.out.println("Hi , I am method1 is class B");
  }
}