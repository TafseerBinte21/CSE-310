interface A
{
  void method1();
}

interface B 
{
  void method2();
}

interface C extends A,B
{
  void method3();
}