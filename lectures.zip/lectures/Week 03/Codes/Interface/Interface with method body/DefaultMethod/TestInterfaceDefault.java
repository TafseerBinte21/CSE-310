class TestInterfaceDefault
{  
  public static void main(String args[])
  {  
    Drawable d=new Rectangle();  
    d.draw();  
    d.msg();  
  }
}