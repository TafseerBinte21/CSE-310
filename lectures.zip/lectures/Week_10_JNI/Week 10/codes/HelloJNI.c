// Save as "HelloJNI.c"
#include <jni.h>        // JNI header provided by JDK
#include <stdio.h>      // C Standard IO Header
#include "HelloJNI.h"   // Generated
 
// Implementation of the native method sayHello()
JNIEXPORT void JNICALL Java_HelloJNI_sayHello(JNIEnv *env, jobject thisObj, jstring who, jint times) {
   // printf("Hello World!\n");
   // return;

	jint i;
	jboolean iscopy;
	const char *name;
	name = (*env)->GetStringUTFChars(env, who, &iscopy);
	for (i = 0; i < times; i++) {
		printf("Hello %s\n", name);
	}
}

