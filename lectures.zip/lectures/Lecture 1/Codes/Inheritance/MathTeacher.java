public class MathTeacher extends Teacher
{
   String mainSubject = "Maths";
   
   void does()
   {
     System.out.println("Teaches Math");
   }
   
}
