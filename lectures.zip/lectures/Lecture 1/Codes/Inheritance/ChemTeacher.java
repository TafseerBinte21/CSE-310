public class ChemTeacher extends Teacher
{
   String mainSubject = "Chemistry";
   
   void does()
   {
     System.out.println("Teaches Chemistry");
   }
   
}
