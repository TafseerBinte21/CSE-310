class Teacher {
   String designation = "Teacher";
   String college = "Notre Dame";
   void does()
   {
     System.out.println("Teaching");
   }
}
