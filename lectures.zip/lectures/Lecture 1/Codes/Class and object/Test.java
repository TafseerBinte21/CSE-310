public class Test
 {
     public static void main(String args[])
     {
       House obj = new House();
       obj.address = "Salman";
       System.out.println(obj.address);
       obj.openDoor();
       obj.closeDoor();
  }
 }
