class House 
    {
     String address;
     String color;
     double are;
     void openDoor()
     {
       System.out.println("Door is Open");
     }
     void closeDoor()
     {
        System.out.println("Door is closed");
     }
 }
