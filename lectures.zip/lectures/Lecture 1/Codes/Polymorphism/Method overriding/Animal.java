class Animal{
   public void animalSound()
   {
     System.out.println("Default Sound");
   }
}
