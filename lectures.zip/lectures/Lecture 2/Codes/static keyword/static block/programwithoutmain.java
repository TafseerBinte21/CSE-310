class programwithoutmain
{  
  static{  
  System.out.println("static block is invoked");  
  System.exit(0);  
  }  
} 